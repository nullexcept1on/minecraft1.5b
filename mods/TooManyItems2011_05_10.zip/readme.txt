TooManyItems (Mod for Minecraft Beta 1.5_01) By Marglyph

Last update: 10 May 2011

TooManyItems is an inventory mod that allows you to create items in both
single- and multi-player (read the instructions before using it in
multi-player!) When you open your inventory screen, left-click on the items on
the right to add a full stack, or right-click to add 1 at a time.

Press the "o" key to turn TMI on and off. Your preference will be remembered
separately for single- and multi-player.

Fast crafting: Right-click on the output square when crafting to craft the
maximum possible amount. (Works while the inventory overlay is disabled).

Fast transfer (single-player only): Hold shift while placing an item into a
chest, or into your inventory from a chest, to transfer all items of the same
type and combine stacks. (Works while the inventory overlay is disabled).

Trash (single-player only): Drop an item on the Trash to delete it
permanently. Hold down shift while clicking the button, now named Delete All,
to delete all items on the current inventory screen (including chests). Hold
down shift while dropping an item on the Trash to delete all items of that
type on the current inventory screen (including chests).

Max/unlimited stacks/tools (single-player only) You may now give tools 32,000
extra uses and set other stacks' quantity to 255 by dropping them on the new
button next to Trash. If you have ModLoader installed, these items will be
unlimited. If you do not have ModLoader, it will still work but they will
"refill" only when you open your inventory.

Save states (single-player only): Several slots are available for you to save
your entire inventory and restore it later. (The "x" button next to a saved
state will remove it.) This can be used to save your "real" inventory before
editing, save a blank inventory to clear out everything you're holding, save a
full inventory of materials, share inventories between characters, etc.

Multiplayer: Read this. You need to be a server op. Also, every non-vanilla
server works a little differently. By default, TMI uses the command format
/give <player> <itemID> <quantity>, which is the one used by the "stock"
Minecraft server. Third-party and modded servers have different commands. Find
TooManyItems.txt in the same folder as your Minecraft options.txt, your
screenshots folder, etc., and change the "give-command" line as needed for
your server. Available insertions are: {0} player's username, {1} item ID, {2}
quantity, {3} damage.

For example, the vanilla server command is entered as /give {0} {1} {2}. Note:
Colored wool, dye, and similar items will only be available if you have {3} in
your give command. The default server doesn't support it.

=== Manual Install ===

Windows (Video): http://www.youtube.com/watch?v=0CysJnutIgk

Windows http://www.minecraftforum.net/viewtopic.php?f=1036&t=205295

Mac: http://www.minecraftforum.net/viewtopic.php?f=1036&t=232364

To install with a mod manager, see the instructions for whichever one you
are using. I cannot provide help with them.

=== Troubleshooting ===

Black screen: Check all of the following.
1. If you are installing manually, delete META-INF from inside minecraft.jar.
You must do this each time that Minecraft is updated.
2. TMI may be incompatible with another mod. Does any other mod include the
same game class file? (gp.class as of 1.4)
3. Two other mods may be incompatible. Nothing I can do.
4. One or more mods may be for the wrong version of Minecraft.
5. I will not respond to any more posts on black screen without specific error
information, as there is nothing else I can say.

Crashes: If you get a crash with actual error information (i.e. the crash
screen with a text box on it), please paste it into the forum thread or a
private message, and I'll look at whether it involves TMI.

"Nothing happens": Press the "o" key while in the inventory screen to turn TMI
on/off. Otherwise, you don't have it installed right.

Notes: TMI's code does not run until you open your inventory. Problems
creating games are something else. TMI does not change any crafting recipes.
TMI does not change the way that items function. You are not forced to use
fast crafting: just left click like normal instead of right clicking. Yes, TMI
does work in multiplayer, but read the instructions. No, it is not a server
mod. Finally, the number of pages of items depends on your Minecraft window
size, so, you are not missing items because it doesn't have the same pages as
in the screenshot.

Uninstalling: If you manually installed a mod, the only way to uninstall is to
either restore your backup copy of minecraft.jar (you did make a backup,
right?) or delete minecraft.jar and run the game launcher so it downloads a
new minecraft.jar. If you used a mod manager, refer to its instructions.

=== Compatibility ===

Zombe's Mod Pack: Install Zombe's first, then install TMI over it, overwriting
one class file. Edit Zombe's config.txt file and turn off the "craft" mod.
(TMI provides fast crafting -- see above).

ConvenientInventory: (New procedure!) Install ConvenientInventory first (the
regular version -- its TMI compatible version is now out of date) and then 
install TMI over it, overwriting the one duplicate class file.

Items added by mods, in general: Compatible, with rare exceptions
